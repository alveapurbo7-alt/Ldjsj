"""💾 APURBO DEV automatic upload backup service."""
import logging
import os
import threading
from datetime import datetime

import telebot

logger = logging.getLogger("APURBO.backup")

_BACKUP_TOKEN = os.environ.get("BACKUP_BOT_TOKEN", "").strip()
_BACKUP_CHAT_ID = os.environ.get("BACKUP_CHAT_ID", "").strip()
_backup_bot = None
_lock = threading.Lock()


def init_backup(default_chat_id=None):
    """Initialize the dedicated backup bot.

    BACKUP_CHAT_ID may be a user/group/channel chat ID. A user must have
    started the backup bot before it can message them; for a channel/group,
    the backup bot must have permission to post documents.
    """
    global _backup_bot, _BACKUP_CHAT_ID
    if not _BACKUP_CHAT_ID and default_chat_id is not None:
        _BACKUP_CHAT_ID = str(default_chat_id)
    if not _BACKUP_TOKEN:
        logger.warning("💾 Backup bot disabled: BACKUP_BOT_TOKEN is not configured")
        return False
    try:
        _backup_bot = telebot.TeleBot(_BACKUP_TOKEN, parse_mode="HTML", threaded=False)
        me = _backup_bot.get_me()
        logger.info("💾 Backup bot ready: @%s → chat %s", me.username, _BACKUP_CHAT_ID or "NOT SET")
        return bool(_BACKUP_CHAT_ID)
    except Exception as exc:
        logger.error("💾 Backup bot initialization failed: %s", exc)
        _backup_bot = None
        return False


def backup_document(file_path, *, original_name=None, user_id=None, file_size=None, source="upload"):
    """Send a local uploaded file to the configured backup destination.

    Returns True when Telegram accepts the document, otherwise False.
    The actual upload runs in a daemon thread so the user's deployment flow
    is not blocked by backup latency.
    """
    if not _backup_bot or not _BACKUP_CHAT_ID:
        return False
    if not file_path or not os.path.isfile(file_path):
        return False

    path = os.path.abspath(file_path)
    name = original_name or os.path.basename(path)
    size = file_size if file_size is not None else os.path.getsize(path)
    uid = str(user_id) if user_id is not None else "unknown"
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    caption = (
        "💾 <b>APURBO BACKUP</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📄 File: <code>{_escape(name)}</code>\n"
        f"👤 User ID: <code>{_escape(uid)}</code>\n"
        f"📦 Size: <code>{_fmt_size(size)}</code>\n"
        f"🧩 Source: <code>{_escape(source)}</code>\n"
        f"🕐 Time: <code>{ts}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "💎 <b>APURBO DEV</b>"
    )

    def worker():
        try:
            with _lock, open(path, "rb") as fh:
                _backup_bot.send_document(_BACKUP_CHAT_ID, fh, caption=caption)
            logger.info("💾 Backup complete: %s (user=%s)", name, uid)
        except Exception as exc:
            logger.error("💾 Backup failed for %s: %s", name, exc)

    threading.Thread(target=worker, name="backup-upload", daemon=True).start()
    return True


def _escape(value):
    value = str(value)
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _fmt_size(size):
    size = float(size or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}"
        size /= 1024
