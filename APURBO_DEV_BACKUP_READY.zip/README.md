# 💎 APURBO DEV — Premium Hosting Panel v6.0

**Premium Telegram Bot Hosting Platform**

## ✨ Included
- 🤖 Python & Node.js bot deployment
- 🔍 Smart entry-file detection
- 📦 Automatic dependency installation
- 💎 Subscription plans & payments
- 🎁 Referral & wallet system
- 🔒 Force-subscribe channels
- 👑 Admin dashboard
- 🛡️ Safe error reporting
- 🔄 Auto-restart & monitoring
- 💾 Database backup and storage monitoring

## 🚀 Installation

```bash
pip install -r requirements.txt
python main.py
```

## 🔐 Environment

Create `.env` with your own values:

```env
BOT_TOKEN=your_bot_token
ERROR_BOT_TOKEN=your_error_bot_token
MONGO_URL=your_mongodb_url
MONGO_URL_BACKUP=your_backup_mongodb_url
OWNER_ID=your_telegram_user_id
BOT_USERNAME=your_bot_username
```

Never publish real bot tokens or database credentials.

## 🧩 Project Structure

```text
├── main.py
├── config.py
├── database.py
├── requirements.txt
├── core/
├── handlers/
└── utils/
```

## 🛠️ Notes
The root project is the canonical version. The old duplicated `apurbo_bot/` package has been removed to prevent stale-code deployment and MongoDB bot-ID inconsistencies.

**Brand:** 💎 APURBO DEV
